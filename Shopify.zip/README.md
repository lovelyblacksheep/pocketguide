1. Run "npm install".
2. Run "npm start" (The project will run on the localhost:3000)
3. Deploy running app online using Ngrok or Vercel. (Copy and Paste the link you get)
4. Add the link as the webhook api in shopify admin page (Admin page->Setting->Notifications->Webhook)
